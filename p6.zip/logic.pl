/*---------------------------------------------------------------

   CMSC 330 Project 6 - Maze Solver and SAT in Prolog

   NAME:

*/


%%%%%%%%%%%%%%%%%%%%%%
% Part 1 - Recursion %
%%%%%%%%%%%%%%%%%%%%%%

% prod - R is product of entries in list L

prod(L,R) :- fail.

% fill - R is list of N copies of X

fill(N,X,R) :- fail.

% genN - R is value between 0 and N-1, in order

genN(N,R) :- fail.

% genXY - R is pair of values [X,Y] between 0 and N-1, in lexicographic order

genXY(N,R) :- fail.

% flat(L,R) - R is elements of L concatentated together, in order

flat(L,R) :- fail.



%%%%%%%%%%%%%%%%%%%%%%%%
% Part 2 - Maze Solver %
%%%%%%%%%%%%%%%%%%%%%%%%

% stats(U,D,L,R) - number of cells w/ openings up, down, left, right
 
stats(U,D,L,R) :- fail.

% validPath(N,W) - W is weight of valid path N rounded to 4 decimal places

validPath(N,W) :- fail.

round4(X,Y) :- T1 is X*10000, T2 is round(T1), Y is T2/10000.

% findDistance(L) - L is list of coordinates of cells at distance D from start

findDistance(L) :- fail.

% solve - True if maze is solvable, fails otherwise.

solve :- fail.


%%%%%%%%%%%%%%%%
% Part 3 - SAT %
%%%%%%%%%%%%%%%%

% TBA

